package com.aniltalariS3175001.fooddonation.fragments

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.fragment.app.Fragment
import com.aniltalariS3175001.fooddonation.DonorDetails
import com.aniltalariS3175001.fooddonation.R
import com.aniltalariS3175001.fooddonation.ui.theme.FoodDonationTheme
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


class DonateFoodFragment : Fragment(R.layout.fragment_donate_food) {
    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<ComposeView>(R.id.donateFoodView).setContent {
            FoodDonationTheme {
                FoodType()
            }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun DonateFoodFragmentP() {
    FoodType()
}


@Composable
fun FoodType() {

    val context = LocalContext.current
    var errorMessage by remember { mutableStateOf("") }

    var foodType by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var expirationDate by remember { mutableStateOf("") }
    var pickupDate by remember { mutableStateOf("") }

    // DatePicker dialog for pickup date
    val calendar = Calendar.getInstance()
    val expirationDatePickerDialog = android.app.DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            expirationDate = "$dayOfMonth/${month + 1}/$year"
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val pickupDatePickerDialog = android.app.DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            pickupDate = "$dayOfMonth/${month + 1}/$year"
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    Column(
        modifier = Modifier.fillMaxSize() // Full screen Column
    ) {
        // Donate Food Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Blue)
                .padding(vertical = 6.dp, horizontal = 16.dp) // Padding inside the bar
        ) {
            Text(
                text = "Donate Food",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                modifier = Modifier.align(Alignment.Center) // Center the text vertically
            )
        }


        Column(
            modifier = Modifier
                .padding(16.dp)

                .fillMaxSize()
        )
        {


            Spacer(modifier = Modifier.height(16.dp))


            // Food Type input
            Text(text = "Food Type")
            BasicTextField(
                value = foodType,
                onValueChange = { foodType = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(50.dp),
                singleLine = true,
                decorationBox = { innerTextField ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.LightGray, MaterialTheme.shapes.medium)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (foodType.isEmpty()) {
                            Text(text = "Enter Food Type", color = Color.Gray)
                        }
                        innerTextField()
                    }
                }
            )

            // Quantity input
            Text(text = "Quantity")

            BasicTextField(
                value = quantity,
                onValueChange = { quantity = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(50.dp),
                singleLine = true,
                decorationBox = { innerTextField ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.LightGray, MaterialTheme.shapes.medium)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (quantity.isEmpty()) {
                            Text(text = "Enter Quantity", color = Color.Gray)
                        }
                        innerTextField()
                    }
                }
            )

            // Expiration Date input
            Text(text = "Expiration Date")

            Box(

                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(50.dp)
                    .clickable {
                        // Handle the click event, e.g., show a date picker
                    }
                    .background(Color.LightGray, MaterialTheme.shapes.medium)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = expirationDate.ifEmpty { "Select Expiration Date" },
                    color = if (expirationDate.isEmpty()) Color.Gray else Color.Black
                )
                Icon(
                    imageVector = Icons.Default.DateRange, // Replace with your desired icon
                    contentDescription = "Calendar Icon",
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(24.dp)
                        .clickable {
                            expirationDatePickerDialog.show()
                        },
                    tint = Color.DarkGray
                )
            }


            // Pickup Date picker
            Text(text = "Select Pickup Date")

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(50.dp)
                    .clickable {
                        // Handle the click event, e.g., show a date picker
                    }
                    .background(Color.LightGray, MaterialTheme.shapes.medium)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = pickupDate.ifEmpty { "Select Pickup Date" },
                    color = if (pickupDate.isEmpty()) Color.Gray else Color.Black
                )
                Icon(
                    imageVector = Icons.Default.DateRange, // Replace with your desired icon
                    contentDescription = "Calendar Icon",
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(24.dp)
                        .clickable {
                            pickupDatePickerDialog.show()
                        },
                    tint = Color.DarkGray
                )
            }




            Spacer(modifier = Modifier.height(24.dp))

            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Button(
                onClick = {
                    when {
                        foodType.isBlank() -> {
                            errorMessage = "Food Type is required."
                        }

                        quantity.isBlank() -> {
                            errorMessage = "Quantity is required."
                        }

                        expirationDate.isBlank() -> {
                            errorMessage = "Expiration Date is required."
                        }

                        pickupDate.isBlank() -> {
                            errorMessage = "Pickup Date is required."
                        }

                        else -> {
                            errorMessage = ""
                            val foodData = FoodData(
                                foodtype = foodType,
                                quantity = quantity,
                                expirationDate = expirationDate,
                                pickUpDate = pickupDate,
                                status = "Pending",
                                userMail = DonorDetails.getDonorEmail(context)!!
                            )
                            saveFoodToDB(foodData, context)

                        }
                    }


                },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = MaterialTheme.shapes.medium,
                colors = ButtonDefaults.buttonColors(Color(0xFF5D3FD3))
            ) {
                Text(
                    text = "Submit", color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}


    private fun saveFoodToDB(foodData: FoodData, context: Context) {

        val db = FirebaseDatabase.getInstance()
        val ref = db.getReference("Donations")

        val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val orderId = dateFormat.format(Date())

        ref.child(foodData.userMail.replace(".", ",")).child(orderId).setValue(foodData)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {


                    Toast.makeText(context, "Added Successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        "User Registration Failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(
                    context,
                    "User Registration Failed: ${exception.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }





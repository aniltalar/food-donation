package com.aniltalariS3175001.fooddonation




data class DonorData
    (
    var donorFullName: String = "",
    var donorEmail: String ="",
    var donorPassword: String ="",
    )

